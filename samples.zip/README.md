# OwnershipGuard

A small, production-quality ASP.NET Core library that helps prevent **IDOR (Insecure Direct Object Reference)** and **Broken Access Control** by making ownership and tenant access checks easy and hard to forget.

## Response semantics

- **404 Not Found** - Resource does not exist (always).
- **403 Forbidden** - Resource exists but the current user is not allowed (not owner and/or tenant mismatch) (default mode).
- **404 Not Found** (hide mode) - When `HideExistenceWhenForbidden` is true, "exists but not allowed" is also returned as 404.
- **400 Bad Request** - Invalid resource id (e.g. missing route value or not a valid Guid when using typed keys).
- **401 Unauthorized** - User not authenticated; or (when tenant checks are enabled for the entity) tenant claim missing.

## Repo file layout

```
NugetPject/
|-- OwnershipGuard.sln
|-- README.md
|-- LICENSE
|-- .gitignore
|-- src/
|   `-- OwnershipGuard/
|       |-- OwnershipGuard.csproj
|       |-- README.md
|       `-- *.cs
|-- tests/
|   `-- OwnershipGuard.Tests/
|       `-- *.cs
`-- samples/
    `-- OwnershipGuard.DemoApi/
        `-- *.cs
```

## Quick start

### Install (local / project reference)

```bash
dotnet add reference src/OwnershipGuard/OwnershipGuard.csproj
```

Or from NuGet: `dotnet add package OwnershipGuard`

### Register services

```csharp
builder.Services.AddOwnershipGuard(options =>
{
    options.UserIdClaimType = ClaimTypes.NameIdentifier;
    options.TenantIdClaimType = "tenant_id";
    options.UseProblemDetailsResponses = true;
    options.HideExistenceWhenForbidden = false; // 403 when not allowed; true => 404
});
```

### Register descriptor (string id)

Owner-only:

```csharp
var registry = app.Services.GetRequiredService<IOwnershipDescriptorRegistry>();
registry.Register<Document>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId);
```

Owner + tenant:

```csharp
registry.Register<Document>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId,
    d => d.TenantId);
```

### Register descriptor (typed key, e.g. Guid)

Owner-only:

```csharp
registry.Register<Document, Guid>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId);
```

Owner + tenant:

```csharp
registry.Register<Document, Guid>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId,
    tenantSelector: d => d.TenantId);
```

Invalid route id (e.g. not a valid Guid) will result in **400 Bad Request**.

### Minimal API: attach filter to endpoints

```csharp
var filter = new RequireOwnershipFilter("id", typeof(Document));
app.MapGet("/documents/{id}", ...).AddEndpointFilter(filter);
app.MapPut("/documents/{id}", ...).AddEndpointFilter(filter);
app.MapDelete("/documents/{id}", ...).AddEndpointFilter(filter);
```

### MVC controllers

```csharp
[ApiController]
[Route("documents")]
[RequireOwnership("id", typeof(Document))]
public sealed class DocumentsController : ControllerBase
{
    [HttpGet("{id}")]
    public IActionResult Get(string id) => Ok();
}
```

### EF Core query helpers

```csharp
using OwnershipGuard.EntityFrameworkCore;

var myDocs = await db.Documents
    .WhereOwnedBy(userId, d => d.OwnerId)
    .ToListAsync();

var tenantItems = await db.Items
    .WhereTenant(tenantId, i => i.TenantId)
    .ToListAsync();
```

## Configuration

| Option | Default | Description |
|--------|---------|-------------|
| `UserIdClaimType` | `ClaimTypes.NameIdentifier` | Claim type for current user id. |
| `TenantIdClaimType` | `"tenant_id"` | Claim type for current tenant id (used only when the entity is registered with a tenant selector). |
| `UseProblemDetailsResponses` | `true` | If true, filters return ProblemDetails; if false, they return plain status codes. |
| `HideExistenceWhenForbidden` | `false` | When not allowed: `false` = 403; `true` = 404 (hide existence). |

## Security notes

- Helps reduce: IDOR and broken access control by enforcing ownership (and optional tenant) before access.
- Does NOT implement: authentication, RBAC, rate limiting, or input validation. Use ASP.NET Core and your application for those.

## Commands

```bash
dotnet test
dotnet run --project samples/OwnershipGuard.DemoApi
dotnet pack -c Release src/OwnershipGuard/OwnershipGuard.csproj
```

## License

MIT (see `LICENSE`).
