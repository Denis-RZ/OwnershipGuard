# OwnershipGuard

ASP.NET Core library to prevent **IDOR/Broken Access Control** by making ownership and tenant access checks easy and hard to forget.

## Quick start

1. Install: `dotnet add package OwnershipGuard`
2. Register services:

```csharp
services.AddOwnershipGuard(options =>
{
    options.UserIdClaimType = ClaimTypes.NameIdentifier;
    options.TenantIdClaimType = "tenant_id";
    options.UseProblemDetailsResponses = true;
    options.HideExistenceWhenForbidden = false;
});
```

3. Register descriptor (after `var app = builder.Build();`):

Owner-only (string id):

```csharp
registry.Register<Document>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId);
```

Owner + tenant (string id):

```csharp
registry.Register<Document>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId,
    d => d.TenantId);
```

Owner-only (typed key: Guid/int/long):

```csharp
registry.Register<Document, Guid>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId);
```

Owner + tenant (typed key):

```csharp
registry.Register<Document, Guid>(
    sp => sp.GetRequiredService<YourDbContext>().Documents,
    d => d.Id,
    d => d.OwnerId,
    tenantSelector: d => d.TenantId);
```

4. Minimal API filter:

```csharp
app.MapGet("/documents/{id}", ...).AddEndpointFilter(new RequireOwnershipFilter("id", typeof(Document)));
```

5. MVC controllers:

```csharp
[ApiController]
[Route("documents")]
[RequireOwnership("id", typeof(Document))]
public sealed class DocumentsController : ControllerBase
{
    [HttpGet("{id}")]
    public IActionResult Get(string id) => Ok();
}
```

## Configuration

| Option | Default | Description |
|--------|---------|-------------|
| `UserIdClaimType` | `ClaimTypes.NameIdentifier` | Claim type for current user id. |
| `TenantIdClaimType` | `"tenant_id"` | Claim type for current tenant id (used only when the entity is registered with a tenant selector). |
| `UseProblemDetailsResponses` | `true` | If true, filters return ProblemDetails; if false, they return plain status codes. |
| `HideExistenceWhenForbidden` | `false` | When not allowed: `false` = 403; `true` = 404 (hide existence). |

## Response semantics (summary)

- **404**: resource does not exist (always).
- **403**: resource exists but user is not allowed (not owner and/or tenant mismatch) (default).
- **404** (hide mode): when `HideExistenceWhenForbidden=true`, "exists but not allowed" is also returned as 404.
- **400**: invalid typed id (e.g. not a valid Guid for `Register<T, TKey>`).
- **401**: missing user id claim; and (when tenant checks are enabled) missing tenant id claim.
